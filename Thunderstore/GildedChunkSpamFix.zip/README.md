# GildedChunkSpamFix

As the description says, this fixes gilded drones, friendly monsters, or any AI that's gilded spawning so many gold chunks the game lags out and crashes.

It does this by making both players AND drones/monsters/any AI use a cooldown for how often gold chunks can spawn. Only players have this normally, which leads to monsters not having a cooldown and crashing games with gold.
(technically gold spam can still happen if players are getting hit, but players probably won't live long enough for that to happen)

Before: (MEDIA GIF)

After: (MEDIA GIF)