## 1.0.1
When the AI attacks players, the AI are now also are affected by the gilded chunk spawning cooldown, so now any and all gilded players/ai use the chunk spawning cooldowns
- Done via an improved IL hook: it no longer removes any IL and instead makes the IL always jump over the "isPlayer" check for chunk spawning cooldowns

<sub><sup>I also linked the github page to the thunderstore page because I forgot to on release</sup></sub>

## 1.0.0

- First release